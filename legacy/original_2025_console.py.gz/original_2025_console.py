import time
import random
import json
import os # For file operations

# --- Configuration & Data (Advanced Structure) ---

# Global file for user data
USER_DATA_FILE = "eco_hero_profiles.json"

# ASCII Art (for a more engaging console UI)
ASCII_ART = {
    "welcome": r"""
    ✨🌍♻️🌟
  ECO-HERO ACADEMY
  Level Up Your Recycling!
    🌟♻️🌍✨
    """,
    "challenge_start": r"""
    🧠🚀 ECO-CHALLENGE INITIATED! 🚀🧠
    Prove Your Recycling Prowess!
    """,
    "badge_unlocked": r"""
    🏆 BADGE UNLOCKED! 🏆
    """,
    "trophy": r"""
        /|\
       / | \
      /  |  \
     |_______|
    _|_|_|_|_|_
    \         /
     \       /
      \_____/
    """
}

# Regional Recycling Rules (Simplified Simulation)
# In a real advanced app, this would be a database or external API.
# Here, we show how tips can vary slightly.
REGIONAL_RULES = {
    "Eco-City Standard": {
        "plastic": {
            "tip": "Most plastics (1, 2, 5) can be recycled. Rinse well, no plastic bags. Lids *on* bottles.",
            "fun_fact": "Recycling one ton of plastic saves 7,200 kWh of electricity!"
        },
        "paper": {
            "tip": "Newspapers, magazines, mail, cardboard. Greasy pizza boxes, waxed paper, and shredded paper must go in general waste.",
            "fun_fact": "Recycling a 4-foot stack of newspapers saves one tree!"
        },
        "glass": {
            "tip": "Glass bottles and jars. Rinse, and remove lids (they're often different materials). Labels can stay.",
            "fun_fact": "Glass can be recycled infinitely without losing quality!"
        },
        "electronics": {
            "tip": "E-waste is toxic. Find specific drop-off points or certified recyclers. Never in regular bins!",
            "fun_fact": "E-waste is the fastest-growing waste stream; proper recycling prevents pollution."
        }
    },
    "Greenburg Initiative": {
        "plastic": {
            "tip": "Only plastics #1 and #2. Rinse thoroughly. Lids *off* bottles and discarded.",
            "fun_fact": "Plastic recycling reduces landfill waste significantly!"
        },
        "paper": {
            "tip": "All clean paper products, including shredded paper (bagged). Greasy cardboard must be composted or binned.",
            "fun_fact": "Recycled paper uses 60% less energy to produce than virgin paper."
        },
        "glass": {
            "tip": "Clear, brown, and green glass accepted. Rinse and ensure no ceramic or pyrex contaminants. Lids *off*.",
            "fun_fact": "Every ton of recycled glass saves 1,300 pounds of sand!"
        },
        "electronics": {
            "tip": "Special community collection events for e-waste occur monthly. Check city website for dates.",
            "fun_fact": "Many old electronics contain valuable rare earth metals that can be recovered."
        }
    }
}

# Expanded Recycling Guide with common contaminants/non-recyclables
RECYCLING_GUIDE = {
    "plastic": {
        "tip": "Most plastics (bottles, jugs, tubs) can be recycled if clean and have the symbol. Remember to rinse them!",
        "what_not_to_recycle": "Plastic bags, plastic film, Styrofoam, plastic cutlery, toys, or medical waste. These jam machines!",
        "fun_fact": "Plastic can take hundreds of years to decompose in a landfill."
    },
    "paper": {
        "tip": "Newspapers, magazines, mail, cardboard boxes (flattened), paperboard. Keep them dry!",
        "what_not_to_recycle": "Greasy pizza boxes, paper towels, tissues, coffee cups (often lined with plastic), shredded paper (unless bagged according to local rules).",
        "fun_fact": "Recycling one ton of paper saves 17 trees, 7,000 gallons of water, and 3 cubic yards of landfill space."
    },
    "glass": {
        "tip": "Glass bottles and jars (food and beverage). Rinse them out. No need to remove labels.",
        "what_not_to_recycle": "Ceramics, Pyrex, window glass, mirrors, light bulbs, drinking glasses. These have different melting points or compositions.",
        "fun_fact": "Glass can be recycled endlessly without losing quality, making it a truly sustainable material!"
    },
    "metal": {
        "tip": "Aluminum cans, steel/tin cans (food and beverage). Rinse them out. Aerosol cans are often accepted if empty.",
        "what_not_to_recycle": "Scrap metal, aluminum foil (unless balled up and very clean), hazardous waste containers, electronics.",
        "fun_fact": "Recycling aluminum saves 95% of the energy compared to making it from raw materials. Enough to power a TV for 3 hours!"
    },
    "electronics": {
        "tip": "Old phones, computers, batteries, TVs. These are 'e-waste' and contain hazardous materials. Never put in regular bins!",
        "what_not_to_recycle": "Anything electronic that's not specifically handled by an e-waste program.",
        "fun_fact": "E-waste is the fastest-growing waste stream in the world. Proper recycling prevents toxic substances like lead and mercury from polluting our environment."
    },
    "food": {
        "tip": "Compost food waste if possible – it creates nutrient-rich soil! Check if your area has food waste collection.",
        "what_not_to_recycle": "Food scraps should never go into your recycling bin for paper, plastic, glass, or metal. They contaminate recyclables.",
        "fun_fact": "Composting food waste reduces methane gas emissions from landfills, a powerful greenhouse gas."
    },
    "cardboard": {
        "tip": "Corrugated cardboard boxes (delivery boxes, moving boxes). Flatten them and keep them dry.",
        "what_not_to_recycle": "Greasy pizza boxes, wet cardboard, cardboard with heavy wax coatings.",
        "fun_fact": "Recycling cardboard uses 75% less energy than making new cardboard from virgin pulp."
    },
    "batteries": {
        "tip": "Most batteries (AA, AAA, C, D, 9V, button cells, rechargeable) should be recycled at special collection points. Never throw in trash!",
        "what_not_to_recycle": "Car batteries (different program), damaged or leaking batteries (handle with extreme care).",
        "fun_fact": "Many batteries contain valuable metals that can be recovered, and harmful chemicals that should not end up in landfills."
    },
    "clothing": {
        "tip": "Donate usable clothing to charities. For unwearable textiles, check for textile recycling programs in your area.",
        "what_not_to_recycle": "Wet, moldy, or heavily soiled clothing usually cannot be recycled.",
        "fun_fact": "The fashion industry is a major polluter; recycling and reusing clothing reduces its environmental impact."
    }
}

# Quiz Questions for the Eco-Challenge
QUIZ_QUESTIONS = [
    # True/False
    {"type": "tf", "question": "True or False: Greasy pizza boxes can always be recycled with other paper.", "answer": False, "explanation": "Grease contaminates paper, making it non-recyclable. Compost or trash the greasy part!"},
    {"type": "tf", "question": "True or False: All plastics with a recycling symbol are accepted in every curbside recycling program.", "answer": False, "explanation": "Recycling rules vary by location! Always check your local guidelines."},
    {"type": "tf", "question": "True or False: You should rinse glass jars before recycling them.", "answer": True, "explanation": "Rinsing removes food residue that can attract pests and contaminate other recyclables."},
    {"type": "tf", "question": "True or False: Old cell phones can be safely thrown in the regular trash.", "answer": False, "explanation": "E-waste like cell phones contains toxic materials and valuable components; it requires special recycling."},
    {"type": "tf", "question": "True or False: Plastic bags should be put in your curbside recycling bin.", "answer": False, "explanation": "Plastic bags jam recycling machinery. Many grocery stores have special drop-offs for them."},
    {"type": "tf", "question": "True or False: Ceramics and Pyrex dishes can be recycled with glass bottles.", "answer": False, "explanation": "Ceramics and Pyrex have different melting points and compositions than glass bottles, contaminating the batch."},

    # Multiple Choice
    {"type": "mc", "question": "Which of these materials is generally NOT accepted in curbside recycling bins?",
     "options": ["A. Aluminum cans", "B. Glass bottles", "C. Styrofoam cups", "D. Cardboard boxes"], "answer": "C",
     "explanation": "Styrofoam is notoriously difficult to recycle and rarely accepted in curbside programs."},
    {"type": "mc", "question": "What is the best way to dispose of old batteries?",
     "options": ["A. Throw them in the trash", "B. Place them in the recycling bin with plastics", "C. Take them to a special battery collection point", "D. Flush them down the toilet"], "answer": "C",
     "explanation": "Batteries contain hazardous materials and should be recycled at designated collection points."},
    {"type": "mc", "question": "Before recycling plastic bottles, what is the most important step?",
     "options": ["A. Remove the label", "B. Rinse them out", "C. Flatten them completely", "D. Put the lid back on tightly"], "answer": "B",
     "explanation": "Rinsing removes food and liquid residue, preventing contamination and odors."},
    {"type": "mc", "question": "Which material can be recycled endlessly without losing quality?",
     "options": ["A. Plastic", "B. Paper", "C. Glass", "D. Textiles"], "answer": "C",
     "explanation": "Glass is unique in its ability to be recycled repeatedly without degradation."},
    {"type": "mc", "question": "What is 'e-waste'?",
     "options": ["A. Everyday trash", "B. Electronic waste like old computers and phones", "C. Organic food scraps", "D. Excess paper waste"], "answer": "B",
     "explanation": "E-waste refers to discarded electronic devices, which require special handling due to hazardous components."},
]

# Achievements/Badges
BADGES = {
    "First Step": {"desc": "Completed your first Eco-Challenge round.", "threshold": {"challenge_rounds": 1}},
    "Recycling Rookie": {"desc": "Scored 3 points in Eco-Challenge.", "threshold": {"challenge_score": 3}},
    "Material Master": {"desc": "Viewed tips for 5 different materials.", "threshold": {"materials_viewed": 5}},
    "Eco-Enthusiast": {"desc": "Played 5 Eco-Challenge rounds.", "threshold": {"challenge_rounds": 5}},
    "Challenge Conqueror": {"desc": "Achieved a perfect score in a 5-question challenge round.", "threshold": {"perfect_challenge": True}},
    "Knowledge Seeker": {"desc": "Used the Eco-AI Advisor 3 times.", "threshold": {"ai_advisor_uses": 3}},
    "Green Guardian": {"desc": "Scored 10 points in Eco-Challenge.", "threshold": {"challenge_score": 10}}
}

# --- User Profile Management ---

class UserProfile:
    def __init__(self, username):
        self.username = username
        self.score = 0
        self.highest_score = 0
        self.challenge_rounds_played = 0
        self.materials_viewed = set()
        self.ai_advisor_uses = 0
        self.badges = set()
        self.quiz_history = [] # To track wrong answers for adaptive learning
        self.current_region = "Eco-City Standard" # Default region

    def save(self):
        try:
            # Load all profiles
            all_profiles = {}
            if os.path.exists(USER_DATA_FILE):
                with open(USER_DATA_FILE, 'r') as f:
                    # Handle empty file case
                    file_content = f.read()
                    if file_content:
                        all_profiles = json.loads(file_content)
            
            # Update current profile
            profile_data = {
                "score": self.score,
                "highest_score": self.highest_score,
                "challenge_rounds_played": self.challenge_rounds_played,
                "materials_viewed": list(self.materials_viewed), # Convert set to list for JSON
                "ai_advisor_uses": self.ai_advisor_uses,
                "badges": list(self.badges),
                "quiz_history": self.quiz_history,
                "current_region": self.current_region
            }
            all_profiles[self.username] = profile_data

            # Save all profiles back
            with open(USER_DATA_FILE, 'w') as f:
                json.dump(all_profiles, f, indent=4)
            print(f"\n✨ Profile '{self.username}' saved successfully! ✨")
        except json.JSONDecodeError:
            print(f"Warning: '{USER_DATA_FILE}' is corrupted or empty. Starting fresh or attempting overwrite.")
            # If corrupted, overwrite with just current profile
            with open(USER_DATA_FILE, 'w') as f:
                json.dump({self.username: profile_data}, f, indent=4)
        except Exception as e:
            print(f"Error saving profile: {e}")


    @staticmethod
    def load(username):
        if os.path.exists(USER_DATA_FILE):
            try:
                with open(USER_DATA_FILE, 'r') as f:
                    file_content = f.read()
                    if not file_content: # Handle empty file
                        return None
                    all_profiles = json.loads(file_content)
                    if username in all_profiles:
                        profile_data = all_profiles[username]
                        profile = UserProfile(username)
                        profile.score = profile_data.get("score", 0)
                        profile.highest_score = profile_data.get("highest_score", 0)
                        profile.challenge_rounds_played = profile_data.get("challenge_rounds_played", 0)
                        profile.materials_viewed = set(profile_data.get("materials_viewed", []))
                        profile.ai_advisor_uses = profile_data.get("ai_advisor_uses", 0)
                        profile.badges = set(profile_data.get("badges", []))
                        profile.quiz_history = profile_data.get("quiz_history", [])
                        profile.current_region = profile_data.get("current_region", "Eco-City Standard")
                        print(f"\nWelcome back, {username}! Loading your progress...")
                        return profile
            except json.JSONDecodeError:
                print(f"Error: '{USER_DATA_FILE}' is corrupted. Cannot load profiles.")
                return None
        return None

    def check_and_unlock_badges(self):
        newly_unlocked = []
        for badge_name, badge_info in BADGES.items():
            if badge_name not in self.badges:
                unlocked = True
                if "challenge_rounds" in badge_info["threshold"] and self.challenge_rounds_played < badge_info["threshold"]["challenge_rounds"]:
                    unlocked = False
                if "challenge_score" in badge_info["threshold"] and self.score < badge_info["threshold"]["challenge_score"]:
                    unlocked = False
                if "materials_viewed" in badge_info["threshold"] and len(self.materials_viewed) < badge_info["threshold"]["materials_viewed"]:
                    unlocked = False
                if "ai_advisor_uses" in badge_info["threshold"] and self.ai_advisor_uses < badge_info["threshold"]["ai_advisor_uses"]:
                    unlocked = False
                # Special check for perfect challenge: This badge is added immediately in eco_challenge if earned.
                # So we just check if it's already in the set here.

                if unlocked:
                    self.badges.add(badge_name)
                    newly_unlocked.append(badge_name)
                    print(ASCII_ART["badge_unlocked"])
                    print(f"       {badge_name}: {badge_info['desc']}")
                    print(ASCII_ART["trophy"])
                    time.sleep(2)
        return newly_unlocked

# --- Core Functions ---

def display_tip(material, user_profile):
    material = material.lower()
    if material not in RECYCLING_GUIDE:
        print("Sorry, we don't have detailed information on that material. Try another!\n")
        return

    user_profile.materials_viewed.add(material)
    user_profile.check_and_unlock_badges() # Check badges after viewing material

    print(f"\n--- 💡 {material.capitalize()} Recycling Guide ({user_profile.current_region}) 💡 ---")

    # Prioritize regional rules if they exist for this material
    if user_profile.current_region in REGIONAL_RULES and material in REGIONAL_RULES[user_profile.current_region]:
        tip_info = REGIONAL_RULES[user_profile.current_region][material]
        print(f"📝 Tip: {tip_info['tip']}")
        print(f"🧠 Fun Fact: {tip_info['fun_fact']}")
    else:
        # Fallback to general guide
        general_info = RECYCLING_GUIDE[material]
        print(f"📝 Tip: {general_info['tip']}")
        print(f"❌ What NOT to Recycle: {general_info['what_not_to_recycle']}")
        print(f"🧠 Fun Fact: {general_info['fun_fact']}")
    print("-" * (len(material) + 26)) # Dynamic line length


def eco_challenge(user_profile):
    print(ASCII_ART["challenge_start"])
    time.sleep(1.5)

    num_questions = 5
    correct_in_round = 0
    
    # Adaptive learning: prioritize questions user got wrong before
    questions_to_ask = []
    if user_profile.quiz_history:
        # Get unique questions from history
        unique_history_questions = []
        seen_questions = set()
        for q_data in user_profile.quiz_history:
            q_id = (q_data["question"], q_data["type"]) # Simple ID for uniqueness
            if q_id not in seen_questions:
                unique_history_questions.append(q_data)
                seen_questions.add(q_id)
        
        random.shuffle(unique_history_questions)
        questions_to_ask.extend(unique_history_questions[:min(len(unique_history_questions), 2)]) # Up to 2 from history

    # Add new random questions to fill the rest
    # Ensure new questions are not already in questions_to_ask
    current_q_ids = {(q["question"], q["type"]) for q in questions_to_ask}
    new_questions_pool = [q for q in QUIZ_QUESTIONS if (q["question"], q["type"]) not in current_q_ids]
    
    random.shuffle(new_questions_pool)
    questions_to_ask.extend(new_questions_pool[:num_questions - len(questions_to_ask)])
    
    # Ensure we have enough questions (might be an issue if quiz_history is huge or QUIZ_QUESTIONS is small)
    if len(questions_to_ask) < num_questions:
        print("Warning: Not enough unique questions available for a full challenge round at the moment.")
        # Fill remaining with duplicates if necessary, or just run with fewer questions
        # For simplicity, we'll just run with fewer if that happens.
        pass

    user_profile.quiz_history = [] # Reset history for this round's *new* incorrect answers

    for i, q_data in enumerate(questions_to_ask):
        if i >= num_questions: # Cap at num_questions
            break
        print(f"\n--- Question {i+1}/{num_questions} ---")
        print(f"❓ {q_data['question']}")

        is_correct = False
        user_answer = "" # Initialize to capture user input
        if q_data["type"] == "tf":
            while True:
                user_answer = input("Enter 'T' for True or 'F' for False: ").strip().upper()
                if user_answer in ['T', 'F']:
                    break
                else:
                    print("Invalid input. Please enter 'T' or 'F'.")
            if (user_answer == 'T' and q_data['answer'] == True) or \
               (user_answer == 'F' and q_data['answer'] == False):
                is_correct = True
        elif q_data["type"] == "mc":
            for option in q_data["options"]:
                print(option)
            while True:
                user_answer = input("Enter your choice (A, B, C, D): ").strip().upper()
                if user_answer in ['A', 'B', 'C', 'D']:
                    break
                else:
                    print("Invalid input. Please enter A, B, C, or D.")
            if user_answer == q_data['answer']:
                is_correct = True
        
        if is_correct:
            print("🎉 Correct! You're an Eco-Hero!")
            correct_in_round += 1
        else:
            print("❌ Incorrect. Don't worry, every mistake is a learning opportunity!")
            print(f"💡 Explanation: {q_data['explanation']}")
            user_profile.quiz_history.append(q_data) # Add to history to re-ask later

        time.sleep(1.5)

    print("\n--- Challenge Summary ---")
    print(f"You got {correct_in_round} out of {num_questions} questions correct!")
    user_profile.score += correct_in_round
    user_profile.challenge_rounds_played += 1
    user_profile.highest_score = max(user_profile.highest_score, user_profile.score)

    if correct_in_round == num_questions:
        print("🌟 PERFECT SCORE! You're a Recycling Master!")
        if "Challenge Conqueror" not in user_profile.badges:
            user_profile.badges.add("Challenge Conqueror")
            print(ASCII_ART["badge_unlocked"])
            print(f"       Challenge Conqueror: {BADGES['Challenge Conqueror']['desc']}")
            print(ASCII_ART["trophy"])
            time.sleep(2)

    user_profile.check_and_unlock_badges() # Check other badges after challenge
    print(f"Your total score: {user_profile.score}")
    print(f"Rounds played: {user_profile.challenge_rounds_played}")
    time.sleep(2)


def eco_ai_advisor(user_profile):
    print("\n--- 🤖 Eco-AI Advisor 🤖 ---")
    print("I'm here to help with general recycling questions.")
    print("Ask me about common recycling doubts, e.g., 'What about plastic bags?', 'Can I recycle dirty items?', 'What is composting?'")
    print("Type 'back' to return to the main menu.")

    user_profile.ai_advisor_uses += 1
    user_profile.check_and_unlock_badges()

    while True:
        question = input("\nYour question: ").strip().lower()
        if question == 'back':
            print("Returning to main menu.")
            break

        response_found = False
        if "plastic bags" in question or "plastic film" in question:
            print("🤖 Advisor: Plastic bags and film typically cannot go into curbside recycling bins as they jam machinery. Look for special drop-off bins at grocery stores!")
            response_found = True
        elif "dirty" in question or "greasy" in question or "food residue" in question:
            print("🤖 Advisor: Recyclables must be clean and free of food residue. Dirty items can contaminate entire batches, making them unrecyclable. Always rinse containers!")
            response_found = True
        elif "compost" in question or "food waste" in question:
            print("🤖 Advisor: Composting is an excellent way to recycle food scraps and yard waste. It creates nutrient-rich soil and reduces landfill methane emissions. Check for local composting programs!")
            response_found = True
        elif "batteries" in question or "old battery" in question:
            print("🤖 Advisor: Never put batteries in the regular trash or recycling bin! They contain hazardous chemicals and can even cause fires. Look for battery recycling drop-offs at stores or waste centers.")
            response_found = True
        elif "electronics" in question or "e-waste" in question:
            print("🤖 Advisor: Old electronics (e-waste) should never be trashed. They contain valuable metals and toxic chemicals. Find a certified e-waste recycler or special collection event.")
            response_found = True
        elif "light bulbs" in question or "bulbs" in question:
            print("🤖 Advisor: Most light bulbs (incandescent, LED) are not recyclable in curbside bins. Fluorescent bulbs often contain mercury and need special disposal. Check your local hazardous waste facilities.")
            response_found = True
        elif "shredded paper" in question:
            print("🤖 Advisor: Shredded paper is tricky. It's often too small for recycling facilities to process effectively. Some areas accept it if securely bagged in a clear plastic bag. Check local rules!")
            response_found = True
        elif "lids" in question or "caps" in question:
            print("🤖 Advisor: Whether to leave lids on or off plastic bottles/jars varies by region and plastic type. Some facilities prefer them off, others say leave them on if smaller than 3 inches. Best to check your local rules!")
            response_found = True
        elif "what can i recycle" in question or "what should i recycle" in question:
             print("🤖 Advisor: Common recyclables include clean plastic bottles/jugs/tubs (with symbols), paper, cardboard, glass bottles/jars, and metal food/beverage cans. Always check local guidelines for specifics!")
             response_found = True
        elif "why recycle" in question:
            print("🤖 Advisor: Recycling saves energy, reduces landfill waste, conserves natural resources, lessens pollution, and creates jobs. It's vital for a sustainable future!")
            response_found = True
        else:
            print("🤖 Advisor: I can help with general recycling questions. Please rephrase or ask about specific common items. If it's about a specific material, try the 'Get a recycling tip' option!")
            response_found = True # Still counts as a use

        time.sleep(1)


def show_profile(user_profile):
    print("\n--- 👤 Your Eco-Hero Profile 👤 ---")
    print(f"Username: {user_profile.username}")
    print(f"Current Score: {user_profile.score}")
    print(f"Highest Score: {user_profile.highest_score}")
    print(f"Eco-Challenge Rounds Played: {user_profile.challenge_rounds_played}")
    print(f"Materials Viewed: {len(user_profile.materials_viewed)}")
    print(f"Eco-AI Advisor Uses: {user_profile.ai_advisor_uses}")
    print(f"Current Region Setting: {user_profile.current_region}")

    print("\n--- 🏆 Your Badges 🏆 ---")
    if not user_profile.badges:
        print("No badges unlocked yet! Keep learning and challenging yourself!")
    else:
        for badge in sorted(list(user_profile.badges)):
            print(f"- {badge}: {BADGES[badge]['desc']}")
    print("-" * 30)
    time.sleep(2)


def manage_profile():
    while True:
        print("\n--- Profile Management ---")
        print("1. Load Existing Profile")
        print("2. Create New Profile")
        print("3. View Leaderboard")
        print("4. Back to Main Menu")
        profile_choice = input("Enter your choice: ")

        if profile_choice == '1':
            username = input("Enter username to load: ").strip()
            loaded_profile = UserProfile.load(username)
            if loaded_profile:
                return loaded_profile
            else:
                print("Profile not found. Please try again or create a new one.")
        elif profile_choice == '2':
            username = input("Enter a new username: ").strip()
            if username:
                if UserProfile.load(username):
                    print("A profile with that username already exists. Please choose a different one or load the existing one.")
                else:
                    new_profile = UserProfile(username)
                    new_profile.save() # Save immediately after creation
                    print(f"Profile '{username}' created!")
                    return new_profile
            else:
                print("Username cannot be empty.")
        elif profile_choice == '3':
            show_leaderboard()
        elif profile_choice == '4':
            return None # Go back to main menu loop without a profile
        else:
            print("Invalid choice. Please enter 1, 2, 3, or 4.")

def show_leaderboard():
    if not os.path.exists(USER_DATA_FILE):
        print("\nNo profiles found yet. Be the first Eco-Hero!")
        return

    try:
        with open(USER_DATA_FILE, 'r') as f:
            all_profiles = json.load(f)

        leaderboard_data = []
        for username, data in all_profiles.items():
            leaderboard_data.append({"username": username, "score": data.get("highest_score", 0), "rounds": data.get("challenge_rounds_played", 0)})
        
        # Sort by highest score, then by rounds played
        leaderboard_data.sort(key=lambda x: (x["score"], x["rounds"]), reverse=True)

        print("\n--- 👑 Eco-Hero Leaderboard 👑 ---")
        if not leaderboard_data:
            print("No scores yet. Take on the challenge!")
        else:
            print(f"{'Rank':<5}{'Username':<15}{'High Score':<12}{'Rounds':<8}")
            print("-" * 40)
            for i, entry in enumerate(leaderboard_data[:10]): # Show top 10
                print(f"{i+1:<5}{entry['username']:<15}{entry['score']:<12}{entry['rounds']:<8}")
        print("-" * 40)
        time.sleep(2)
    except Exception as e:
        print(f"Error loading leaderboard: {e}")

def change_region(user_profile):
    print("\n--- 🌎 Select Your Recycling Region 🌎 ---")
    print("Recycling rules can vary! Choose a region to get tailored advice.")
    regions = list(REGIONAL_RULES.keys())
    for i, region in enumerate(regions):
        print(f"{i+1}. {region}")
    
    while True:
        try:
            choice = int(input(f"Enter number for your region (1-{len(regions)}): "))
            if 1 <= choice <= len(regions):
                user_profile.current_region = regions[choice - 1]
                print(f"Your region is now set to: {user_profile.current_region}")
                break
            else:
                print("Invalid number. Please choose from the list.")
        except ValueError:
            print("Invalid input. Please enter a number.")
    time.sleep(1)

# --- Main Application Loop ---

def main():
    print(ASCII_ART["welcome"])
    time.sleep(1.5)

    current_user = None

    while True:
        if current_user is None:
            print("\n--- Welcome, Eco-Hero! ---")
            print("1. Manage Profiles (Load/Create/Leaderboard)")
            print("2. Exit Application")
            choice = input("Enter your choice: ")

            if choice == '1':
                current_user = manage_profile()
                if current_user:
                    print(f"\nActive Profile: {current_user.username}")
                    # After loading, immediately check for any newly met badge conditions
                    current_user.check_and_unlock_badges()
            elif choice == '2':
                print("Thank you for being an Eco-Hero! Protecting our planet starts with you. Goodbye! 👋")
                break
            else:
                print("Invalid choice. Please enter 1 or 2.")
                time.sleep(1)
        else:
            print(f"\n--- Main Menu (Eco-Hero: {current_user.username}) ---")
            print("1. Get Recycling Tip")
            print("2. Take the Eco-Challenge!")
            print("3. Ask Eco-AI Advisor")
            print("4. View My Profile & Badges")
            print("5. Change My Recycling Region")
            print("6. Save & Log Out")
            print("7. Exit Application (without saving)")
            choice = input("Enter your choice: ")

            if choice == '1':
                material = input("Enter a material (e.g., plastic, glass, electronics, batteries, clothing): ").lower()
                display_tip(material, current_user)
            elif choice == '2':
                eco_challenge(current_user)
            elif choice == '3':
                eco_ai_advisor(current_user)
            elif choice == '4':
                show_profile(current_user)
            elif choice == '5':
                change_region(current_user)
            elif choice == '6':
                current_user.save()
                current_user = None # Log out
                print("Logged out. Please manage profiles to log back in or create new.")
                time.sleep(1)
            elif choice == '7':
                print("Exiting application without saving your current session's progress.")
                print("Thank you for being an Eco-Hero! Protecting our planet starts with you. Goodbye! 👋")
                break
            else:
                print("Invalid choice. Please enter a number from 1 to 7.")
                time.sleep(1)

if __name__ == '__main__':
    main()
